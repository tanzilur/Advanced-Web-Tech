<body>
<div class='center'>
<h1>Welcome To Registration</h1>
<form action="/register" method="post">
<?php echo e(csrf_field()); ?>


<span><b>Username</b></span> <input type="text" name="username">
<?php if($errors->has('username')): ?>
<b><?php echo e($errors->first('username')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Email</b></span> <input type="text" name="email">
<?php if($errors->has('email')): ?>
<b><?php echo e($errors->first('email')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Password</b></span> <input type="int" name="password">
<?php if($errors->has('password')): ?>
<b><?php echo e($errors->first('password')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Address</b></span>
<textarea id="address" name="address" rows="4" cols="20"></textarea>
<?php if($errors->has('address')): ?>
<b><?php echo e($errors->first('address')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Occupation</b></span>
<select name="occupation" id="occupation">
<option value="">Select</option>
<option value="Farmer">Farmer</option>
<option value="Fisherman">Fisherman</option>
<option value="AgriOfficer">Agri-Officer</option>
<option value="Serviceholder">Serviceholder</option>
<option value="Newentrepreneur">New entrepreneur</option>
<option value="Other">Other</option>
</select>
<?php if($errors->has('occupation')): ?>
<b><?php echo e($errors->first('occupation')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Gender</b></span>
<input type="radio" name="gender" value="Male">Male
<input type="radio" name="gender" value="Female">Female
<?php if($errors->has('gender')): ?>
<b><?php echo e($errors->first('gender')); ?></b>
<?php endif; ?>
<br><br>

<span><b>Zip-Code</b></span> <input type="int" name="zipcode">
<?php if($errors->has('zipcode')): ?>
<b><?php echo e($errors->first('zipcode')); ?></b>
<?php endif; ?>
<br><br>

<button type="submit" class="registration">Submit</button>
</form>
</div>
</body><?php /**PATH C:\xampp\htdocs\profileupdate\resources\views/register.blade.php ENDPATH**/ ?>