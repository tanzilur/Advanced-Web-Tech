<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function submit()
    {
        return view('register');
    }
    public function get_register(Request $request)
    {
        $this->validate(
            $request,
            [
                'username' => 'required|max:20',
                'email' => 'required|regex:/(.+)@(.+)\.(.+)/i',
                'password' => 'required|regex:/^[0-9,]{6,6}$/',
                'address' => 'regex:/^[a-zA-Z,]+$/',
                'occupation' => 'required',
                'gender' => 'required|string',
                'zipcode' => 'required|regex:/^[0-9]{4,4}$/'
            ],

            [
                'username' => 'Your user name is wrong and username length is maximum 20',
                'email' => 'Your email is not correct,please use this format(abc@gmail.com)',
                'password' => 'Your password is incorrect and password length is 6 numbers',
                'address' => 'Your address is not correct,you can start your address with letter(Dhaka,Khulna)',
                'occupation' => 'Please insert your occupation',
                'gender' => 'Choose your gender',
                'zipcode' => 'Insert Correct zip code with four digits:Hints(1167)'
            ],

        );
        if (isset($error)) {
            $output = $request->address;
            return $output;
        } else {
            $usetable = new User();
            $usetable->username = $request->username;
            $usetable->email = $request->email;
            $usetable->password = $request->password;
            $usetable->address = $request->address;
            $usetable->occupation = $request->occupation;
            $usetable->gender = $request->gender;
            $usetable->zipcode = $request->zipcode;
            $usetable->save();

            return view("login");
        }
    }

    public function login()
    {
        return view('login');
    }


    function logincheck(Request $request)
    {
        $use_table = new User();
        $result = $use_table->where('username', $request->username)->where('password', $request->password)->first();
        // $password = $use_table->where('password', $request->password);
        if (!empty($result)) {
            $request->session()->put('username', $request->username);
            $request->session()->put('password', $request->password);
            $request->session()->put('user', $result);
            return redirect("profile");
            echo "Done";
        } else {
            $output = "Wrong Info";
            return $output;
        }
    }

    public function profile(Request $request)
    {

            return view("loginCheck");
    }

    public function show(Request $request)
    {
        $use_table=User::where('id',$request->id)->first();
        return view('update')->with('user',$use_table);
        
    }

    function group(Request $request){
        $use_table=User::where('id',$request->id)->first();
        $use_table->username = $request->username;
        $use_table->email = $request->email;
        $use_table->address = $request->address;
        $use_table->occupation = $request->occupation;
        $use_table->save();
        $request->session()->put('user', $use_table);
         return redirect("profile");
         }


}
