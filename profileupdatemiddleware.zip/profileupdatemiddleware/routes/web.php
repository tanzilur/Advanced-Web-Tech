<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/profile', [ProfileController::class,'profile'])->middleware('loginCheck');
Route::get('/logout', function () {
    session()->forget('user');
    return redirect('login');
});
Route::get('/register', [ProfileController::class, 'submit']);
Route::post('/register', [ProfileController::class, 'get_register']);

Route::get('/login', [ProfileController::class, 'login']);
Route::post('/startlogin', [ProfileController::class, 'logincheck']);

Route::get('/update', [ProfileController::class, 'show']);
Route::post('/startupdate', [ProfileController::class, 'date']);
