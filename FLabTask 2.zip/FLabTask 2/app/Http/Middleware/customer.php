<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class customer
{
    
    public function handle(Request $request, Closure $next)
    {
        if (auth()->check() && auth()->user()->type == 'customer') {
            return $next($request);
        }
        return redirect()->to('/home');
    }
}