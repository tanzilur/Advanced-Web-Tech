<html>
<head></head>
<body>
    <div>
        <h1>Welcome to Demo Laravel<h1>
</div>
<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div>
    <h3>Advanced Programming in WT</h3>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tanzil\resources\views/layouts/app.blade.php ENDPATH**/ ?>