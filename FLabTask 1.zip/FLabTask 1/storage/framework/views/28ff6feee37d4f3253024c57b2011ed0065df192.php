<html>
<head></head>
<body>
    <h1>Hello Advanced Web</h1>
    <div>
       <?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person=>$age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php echo e($person); ?> <?php echo e($age); ?> <br>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tanzil\resources\views/hello.blade.php ENDPATH**/ ?>