<html>
<head></head>
<body>
    <div>
        <h1>Welcome to Demo Laravel<h1>
</div>
<div>
    @yield('content')
</div>
<div>
    <h3>Advanced Programming in WT</h3>
</div>
</body>
</html>