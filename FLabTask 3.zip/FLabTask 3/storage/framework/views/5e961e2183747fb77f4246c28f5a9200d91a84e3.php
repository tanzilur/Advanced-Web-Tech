
<?php $__env->startSection('content'); ?>
<html>
  <head></head>
  <body>
    <form action="/register" method="post">
      <?php echo e(csrf_field()); ?>

      Name: <input type="text" name="name" value="<?php echo e(old('name')); ?>">
      <?php if($errors->has('name')): ?>
          <span class="">
            <strong><?php echo e($errors->first('name')); ?></strong>
          </span>
      <?php endif; ?><br>
      Profession: <input type="text" name="profession" value="<?php echo e(old('profession')); ?>">
      <?php if($errors->has('profession')): ?>
          <span class="">
            <strong><?php echo e($errors->first('profession')); ?></strong>
          </span>
      <?php endif; ?><br>
      Address: <input type="text" name="address" value="<?php echo e(old('address')); ?>">
      <?php if($errors->has('address')): ?>
          <span class="">
            <strong><?php echo e($errors->first('address')); ?></strong>
          </span>
      <?php endif; ?><br>
      <input type="submit" name="submit">
</form>
</body>
</html>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tanzil\resources\views/registration.blade.php ENDPATH**/ ?>