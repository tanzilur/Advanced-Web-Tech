<body>
<div class='center'>


<h1>Update</h1>
<form action="/startupdate" method="post">
@csrf

<span><b></b></span> <input type="hidden" name="id" value="{{ session('user')->id}}">
<br><br>

<span><b>Username</b></span> <input type="text" name="username" value="{{ session('user')->username}}">
<br><br>

<span><b>Email</b></span> <input type="text" name="email" value="{{ session('user')->email}}">
<br><br>

<span><b>Address</b></span> <input type="text" name="address" value="{{ session('user')->address}}">
<br><br>

<span><b>Occupation</b></span> <input type="text" name="occupation" value="{{ session('user')->occupation}}">
<br><br>

<button type="submit" value="login">Done</button>
</form>
</div>
</body>