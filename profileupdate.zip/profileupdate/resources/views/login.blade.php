<body>
<div class='center'>
<h1>Login</h1>
<form action="/startlogin" method="post">
@csrf
<span><b>Username</b></span> <input type="text" name="username">
<br><br>
<span><b>Password</b></span> <input type="int" name="password">
<br><br>
<button type="submit" value="login">login</button>
</form>
</div>
</body>