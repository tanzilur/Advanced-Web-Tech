<html>
<head></head>
<body>
    <div>
        <h1>Welcome To Homepage<h1>
</div>
<div>
    @yield('content')
</div>
<div>
    <h3>Tanzilur Rahman</h3>
</div>
</body>
</html>