@extends('layouts.app')
@section('title')
Home
@endsection
@section('content')
@endsection
