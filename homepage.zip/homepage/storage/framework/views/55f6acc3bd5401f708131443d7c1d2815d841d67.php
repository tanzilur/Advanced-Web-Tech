<html>
<head></head>
<body>
    <div>
        <h1>Welcome To Homepage<h1>
</div>
<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<div>
    <h3>Tanzilur Rahman</h3>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\homepage\resources\views/layouts/app.blade.php ENDPATH**/ ?>