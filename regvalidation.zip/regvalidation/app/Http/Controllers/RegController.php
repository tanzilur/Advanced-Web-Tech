<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegController extends Controller
{
    function Registration(){
        return view("registration");
}

    function Register(Request $request){
        $this->validate($request,
        [
            'name' => 'required|min:5|string',
            'profession' => 'required|string|max:50',
            'address' => 'required|min:10|string'
        ],
        [
            'required' => 'Please fill up the field',
            'string' => 'Values must be string'
        ]
        );
        $output = "<h1>Submitted</h1>";
        $output.= "Name: ".$request->name;
        $output.= "<br>Profession: ".$request->profession;
        $output.= "<br>Address: ".$request->address;
        return $output;
        return view("register");
}

}
