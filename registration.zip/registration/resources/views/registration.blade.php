<html>
  <head></head>
  <body>
    <h1>Welcome To Registration</h1>
    <form action="/register" method="post">
      {{csrf_field()}}
      Name: <input type="text" name="name" value="{{old('name')}}">
      @if ($errors->has('name'))
          <span class="">
            <strong>{{ $errors->first('name') }}</strong>
          </span>
      @endif<br>
      Profession: <input type="text" name="profession" value="{{old('profession')}}">
      @if ($errors->has('profession'))
          <span class="">
            <strong>{{ $errors->first('profession') }}</strong>
          </span>
      @endif<br>
      Address: <input type="text" name="address" value="{{old('address')}}">
      @if ($errors->has('address'))
          <span class="">
            <strong>{{ $errors->first('address') }}</strong>
          </span>
      @endif<br>
      <input type="submit" name="submit">
</form>
</body>
</html>